<?php
// ===============================================
// 1. データベース接続設定とオブジェクト作成
// ===============================================

// 接続情報 (docker-compose.ymlに基づいた値)
$host = 'mysql'; 
$dbname = 'social_game_placeholder'; // docker-compose.ymlで設定した仮の名前
$user = 'root';
$password = 'p@ssword'; // .ymlで設定したパスワード

$dsn = "mysql:host={$host};dbname={$dbname};charset=utf8mb4";

try {
    $pdo = new PDO($dsn, $user, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    echo "DB接続成功。<br>";
} catch (PDOException $e) {
    exit("DB接続エラー: " . $e->getMessage());
}

// ===============================================
// 2. 強化処理に必要な変数の設定 (今回は確認のため固定値)
//    - 実際はフォーム入力やセッションから取得する
// ===============================================
$user_id = 1; 
$original_card_id = 1; 
$base_id = 1;     // 強化するカードのインスタンスID (id=1)
$material_id = 3; // 素材にするカードのインスタンスID (id=3)


// ===============================================
// 3. 強化トランザクションロジック
// ===============================================
echo "--- 強化処理実行 -- <br>";

try {
    // ------------------------------------
    // 3-1. トランザクション開始
    // ------------------------------------
    $pdo->beginTransaction();

    // ------------------------------------
    // 3-2. 強化後IDの取得 (master_db.cards_table を参照)
    // ------------------------------------
    $stmt = $pdo->prepare("SELECT next_card_id FROM master_db.cards_table WHERE id = ?");
    $stmt->execute([$original_card_id]);
    $result = $stmt->fetch();

    if (!$result || $result['next_card_id'] === NULL) {
        throw new Exception("このカードは最終段階のため強化できません。");
    }
    $new_card_id = $result['next_card_id'];
    echo "元のカードID({$original_card_id})から、新しいカードID({$new_card_id})を取得しました。<br>";

    // ------------------------------------
    // 3-3. ベースカードの更新 (sub_db.users_cards_table)
    // ------------------------------------
    $stmt = $pdo->prepare("UPDATE sub_db.users_cards_table SET card_id = ? WHERE id = ? AND user_id = ?");
    $stmt->execute([$new_card_id, $base_id, $user_id]);

    if ($stmt->rowCount() !== 1) {
        throw new Exception("ベースカードの更新に失敗しました。");
    }
    echo "ベースカードインスタンスID({$base_id})を、新カードID({$new_card_id})に更新しました。<br>";


    // ------------------------------------
    // 3-4. 素材カードの削除 (sub_db.users_cards_table)
    // ------------------------------------
    $stmt = $pdo->prepare("DELETE FROM sub_db.users_cards_table WHERE id = ? AND user_id = ?");
    $stmt->execute([$material_id, $user_id]);
    
    if ($stmt->rowCount() !== 1) {
        throw new Exception("素材カードの削除に失敗しました。");
    }
    echo "素材カードインスタンスID({$material_id})を削除しました。<br>";


    // ------------------------------------
    // 3-5. 全て成功したらコミット
    // ------------------------------------
    $pdo->commit();
    echo "<hr><h1>✅ 強化成功！</h1>";
    echo "ユーザーの所持カードが更新されました。";

} catch (Exception $e) {
    // エラーが発生したらロールバック
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo "<hr><h1>❌ 強化失敗</h1>";
    echo "エラー: " . $e->getMessage();
}
?>